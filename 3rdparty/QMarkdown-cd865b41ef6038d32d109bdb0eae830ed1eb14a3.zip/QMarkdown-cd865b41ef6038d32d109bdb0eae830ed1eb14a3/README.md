# QMarkdown

Transplanted from the [Python Markdown][PythonMarkdown].

[PythonMarkdown]: http://packages.python.org/Markdown/ "Python Markdown"

## Required Library

- [Boost][Boost]
- [Qt5][Qt5]

[Boost]: http://www.boost.org/ "Boost C++ Library"
[Qt5]: http://www.qt.io/ "Qt"

## License

Become BSD license If conform to the original library.

